package newpackage;

import javax.swing.JOptionPane;

public class teste2 {

    public static void main(String[] args) {
        try {
            NewClass chamar = new NewClass();

            int op = Integer.parseInt(JOptionPane.showInputDialog("Digite o operador\n1 para cálcular a área do Triângulo\n2 para calcular a área do Retângulo\n3 para calcular a área do Quadrado"));

            if (op == 1) {
                chamar.tri();
            } else if (op == 2) {
                chamar.retan();
            } else if (op == 3) {
                chamar.quad();
            } else {
                System.out.println("Erro");

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "inválido:");
        }
    }
}
