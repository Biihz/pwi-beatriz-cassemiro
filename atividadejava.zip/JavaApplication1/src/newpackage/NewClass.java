package newpackage;

import javax.swing.JOptionPane;

public class NewClass {

    void tri() {
        int a = Integer.parseInt(JOptionPane.showInputDialog("Digite a Altura: "));
        int b = Integer.parseInt(JOptionPane.showInputDialog("Digite a Base: "));
        int tri = (a + b) / 2;

        JOptionPane.showMessageDialog(null, "Seu resultado é: " + tri);
    }

    void retan() {
        int a = Integer.parseInt(JOptionPane.showInputDialog("Digite a Altura: "));
        int b = Integer.parseInt(JOptionPane.showInputDialog("Digite a Base: "));
        int retan = b * a;

        JOptionPane.showMessageDialog(null, "Seu resultado é: " + retan);
    }

    void quad() {
        int a = Integer.parseInt(JOptionPane.showInputDialog("Digite sua Base/Altura: "));
        int quad = a * 4;

        JOptionPane.showMessageDialog(null, "Seu resultado é: " + quad);
    }
}
